package net.hnf.profiledoseninformatika

data class Dosen(
    var name: String = "",
    var nip: String = "",
    var keahlian : String = "",
    var photo : Int = 0
)